# Dessiner un rectangle

A l'aide du context2D vous dessinez un rectangle dans le Canvas.

Vous pouvez dessinez 3 rectangles pour bien tester le fonctionnement :

- un rectangle sans remplissage avec un contour noir,
- un rectangle sans remplissage avec un contour vert,
- un rectangle plein, rempli de rouge.