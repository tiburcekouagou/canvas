# Dessiner un rectangle

A l'aide du context2D vous écrivez du texte dans le Canvas.

Nous allons écrire "Hello World !" avec 3 couleurs différentes.

1 couleurs pour 'Hello', une pour 'world' et une pour '!'

## Astuce :

Vous allez devoir placer les textes séparément et donc bien les placer avec une distance entre eux (5 pixels par exemple). 
Vous pouvez utiliser la méthode `measureText` pour connaitre la longueur du texte que vous allez écrire et donc savoir où placer le texte suivant (position en pixels).